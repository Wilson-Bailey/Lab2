﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    //VideoGame Interface
    class VideoGame : IComparable<VideoGame>
    {
        public string Name { get; set; }
        public string Platform { get; set; }
        public int Year { get; set; }
        public string Genre { get; set; }
        public string Publisher { get; set; }
        public double NA_Sales { get; set; }
        public double EU_Sales { get; set; }
        public double JP_Sales { get; set; }
        public double Other_Sales { get; set; }
        public double Global_Sales { get; set; }


        //Comparing
        public int CompareTo(VideoGame other)
        {
            return string.Compare(this.Name, other.Name, StringComparison.Ordinal);
        }
        //String Format
        public override string ToString()
        {
            // Custom string representation of a VideoGame object
            return $"{Name,-40} {Platform,-15} {Year,-6} {Genre,-20} {Publisher,-20} {Global_Sales,-10:N2}M";
        }
    }
}

