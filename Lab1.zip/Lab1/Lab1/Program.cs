﻿using Lab1;
using System;
using System.Reflection;
using System.Text;

class Program
{
    static List<VideoGame> videoGames;

    static void Main()
    {
        videoGames = ReadDataAndCreateList();

        if (videoGames != null)
        {
            videoGames.Sort();
            foreach (var game in videoGames)
            {
                Console.WriteLine(game.ToString());
            }

            Console.Write("Choose a publisher: ");
            string userInputPublisher = Console.ReadLine();
            DisplayPublisherGames(userInputPublisher);

            Console.Write("Choose a genre: ");
            string userInputGenre = Console.ReadLine();
            DisplayGenreGames(userInputGenre, userInputPublisher);

            // Display the top 5 games for each platform
            DisplayTop5GamesForEachPlatform();
        }
        else
        {
            Console.WriteLine("Failed to read data from the CSV file. Exiting...");
        }
    }

    static void DisplayPublisherGames(string publisher)
    {
        List<VideoGame> publisherGames = videoGames
            .Where(game => game.Publisher == publisher)
            .OrderBy(game => game.Name)
            .ToList();

        Console.WriteLine($"Games developed by {publisher}, sorted alphabetically:");
        foreach (var game in publisherGames)
        {
            Console.WriteLine(game.ToString());
        }

        double gamesCount = publisherGames.Count;
        double percentage = videoGames.Count > 0 ? (gamesCount / videoGames.Count) * 100 : 0;

        Console.WriteLine($"Out of {videoGames.Count} games, {gamesCount} are developed by {publisher}, which is {percentage:F2}%");
    }

    static void DisplayGenreGames(string genre, string publisher)
    {
        List<VideoGame> genreGames = videoGames
            .Where(game => game.Publisher == publisher && game.Genre == genre)
            .OrderBy(game => game.Name)
            .ToList();

        Console.WriteLine($"Games of the genre {genre} developed by {publisher}, sorted alphabetically:");
        foreach (var game in genreGames)
        {
            Console.WriteLine(game.ToString());
        }

        double totalGamesFromPublisher = videoGames.Count(game => game.Publisher == publisher);
        double gamesCount = genreGames.Count;
        double percentage = totalGamesFromPublisher > 0 ? (gamesCount / totalGamesFromPublisher) * 100 : 0;

        Console.WriteLine($"Out of {totalGamesFromPublisher} games from {publisher}, {gamesCount} are of the genre {genre}, which is {percentage:F2}%");
    }

    //Displaying Top 5 games 

    static void DisplayTop5GamesForEachPlatform()
    {
        var platforms = videoGames.Select(game => game.Platform).Distinct();

        foreach (var platform in platforms)
        {
            Console.WriteLine($"Top 5 games for {platform}:");
            foreach (var topGame in GetTop5Games(platform))
            {
                Console.WriteLine(topGame.ToString());
            }
            Console.WriteLine();
        }
    }

    //Getting top 5 games
    static List<VideoGame> GetTop5Games(string platform)
    {
        return videoGames
            .Where(game => game.Platform == platform)
            .OrderByDescending(game => game.Global_Sales)
            .Take(5)
            .ToList();
    }

    static List<VideoGame> ReadDataAndCreateList()
    {
        List<VideoGame> games = new List<VideoGame>();

        try
        {
            string fileName = "videogame.csv";
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), fileName);

            if (!File.Exists(filePath))
            {
                Console.WriteLine($"Error: File not found - {filePath}");
                return null;
            }

            using (StreamReader reader = new StreamReader(filePath))
            {
                string[] headers = reader.ReadLine()?.Split(',');

                while (!reader.EndOfStream)
                {
                    string[] values = reader.ReadLine()?.Split(',');

                    if (values != null && values.Length == 10)
                    {
                        VideoGame game = new VideoGame
                        {
                            Name = values[0],
                            Platform = values[1],
                            Year = int.Parse(values[2]),
                            Genre = values[3],
                            Publisher = values[4],
                            NA_Sales = double.Parse(values[5]),
                            EU_Sales = double.Parse(values[6]),
                            JP_Sales = double.Parse(values[7]),
                            Other_Sales = double.Parse(values[8]),
                            Global_Sales = double.Parse(values[9])
                        };

                        games.Add(game);
                    }
                    else
                    {
                        Console.WriteLine("Invalid data in the CSV file. Skipping a row.");
                    }
                }
            }

            return games;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error reading data from CSV file");
            return null;
        }
    }
}